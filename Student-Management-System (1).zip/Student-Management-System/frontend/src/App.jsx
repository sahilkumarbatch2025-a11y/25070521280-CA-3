import { useCallback, useEffect, useMemo, useState } from "react";
import {
  GraduationCap, LayoutDashboard, Users, UserPlus, Search, Pencil,
  Trash2, X, Menu, RefreshCw, BookOpen, Mail, Phone, Hash, Building2
} from "lucide-react";

const API = "http://localhost:5000/api/students";
const blankForm = { name: "", prn: "", email: "", department: "Computer Science", year: "2nd Year", phone: "" };

function initials(name = "") {
  return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]?.toUpperCase() || "").join("") || "ST";
}

export default function App() {
  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState(blankForm);
  const [editingId, setEditingId] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [active, setActive] = useState("Dashboard");
  const [mobileMenu, setMobileMenu] = useState(false);

  const loadStudents = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch(`${API}?search=${encodeURIComponent(search)}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Unable to load students.");
      setStudents(data);
    } catch {
      setError("Cannot connect to the backend. Start the backend server and make sure MongoDB is running.");
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => { loadStudents(); }, [loadStudents]);

  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(""), 3500);
    return () => clearTimeout(timer);
  }, [notice]);

  const stats = useMemo(() => ({
    total: students.length,
    departments: new Set(students.map((s) => s.department)).size,
    secondYear: students.filter((s) => s.year === "2nd Year").length
  }), [students]);

  function openAdd() {
    setEditingId(null);
    setForm(blankForm);
    setError("");
    setModalOpen(true);
  }

  function openEdit(student) {
    setEditingId(student._id);
    setForm({
      name: student.name || "", prn: student.prn || "", email: student.email || "",
      department: student.department || "Computer Science", year: student.year || "2nd Year",
      phone: student.phone || ""
    });
    setError("");
    setModalOpen(true);
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setSaving(true);
    setError("");
    try {
      const response = await fetch(editingId ? `${API}/${editingId}` : API, {
        method: editingId ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Could not save student.");
      setModalOpen(false);
      setNotice(editingId ? "Student details updated successfully." : "Student added successfully.");
      await loadStudents();
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  async function deleteStudent(student) {
    if (!window.confirm(`Delete ${student.name}'s record? This cannot be undone.`)) return;
    try {
      const response = await fetch(`${API}/${student._id}`, { method: "DELETE" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Could not delete student.");
      setNotice("Student record deleted.");
      await loadStudents();
    } catch (err) {
      setNotice(err.message || "Could not delete student.");
    }
  }

  const navItems = [
    { label: "Dashboard", icon: LayoutDashboard },
    { label: "Students", icon: Users }
  ];

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><GraduationCap size={25} /></div>
          <div><strong>Campus<span>Flow</span></strong><small>STUDENT PORTAL</small></div>
          <button className="icon-btn mobile-close" onClick={() => setMobileMenu(false)} aria-label="Close menu"><X size={18} /></button>
        </div>
        <div className="nav-caption">WORKSPACE</div>
        <nav>
          {navItems.map(({ label, icon: Icon }) => (
            <button key={label} className={`nav-item ${active === label ? "active" : ""}`}
              onClick={() => { setActive(label); setMobileMenu(false); }}>
              <Icon size={18} /><span>{label}</span>{label === "Students" && <span className="nav-count">{students.length}</span>}
            </button>
          ))}
          <button className="nav-item" onClick={openAdd}><UserPlus size={18} /><span>Add Student</span></button>
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-tip"><div className="tip-icon"><BookOpen size={18} /></div><strong>Keep records organized</strong><p>Manage your student directory from one simple workspace.</p></div>
          <div className="profile"><div className="profile-avatar">F</div><div><strong>FLEXI Project</strong><small>Administrator</small></div><span className="online-dot" /></div>
        </div>
      </aside>

      {mobileMenu && <button className="scrim" aria-label="Close navigation" onClick={() => setMobileMenu(false)} />}

      <main className="main-area">
        <header className="topbar">
          <button className="icon-btn mobile-menu-btn" onClick={() => setMobileMenu(true)} aria-label="Open menu"><Menu size={21} /></button>
          <div className="breadcrumb">Workspace <span>/</span> <strong>{active}</strong></div>
          <div className="topbar-right"><span className="status-dot" /> System dashboard <div className="top-avatar">F</div></div>
        </header>

        <div className="content">
          <section className="welcome-row">
            <div><div className="eyebrow">OVERVIEW</div><h1>{active === "Students" ? "Student Directory" : "Student Dashboard"}<span>.</span></h1><p>Manage student information, all in one place.</p></div>
            <button className="primary-btn" onClick={openAdd}><UserPlus size={17} /> Add student</button>
          </section>

          {notice && <div className="toast"><span>✓</span>{notice}<button onClick={() => setNotice("")} aria-label="Dismiss"><X size={16} /></button></div>}
          {error && !modalOpen && <div className="alert"><strong>Connection issue</strong><span>{error}</span><button className="outline-btn small" onClick={loadStudents}><RefreshCw size={14} /> Retry</button></div>}

          <section className="stats-grid">
            <article className="stat-card"><div className="stat-top"><span>Total students</span><div className="stat-icon violet"><Users size={19} /></div></div><div className="stat-number">{loading ? "—" : stats.total.toString().padStart(2, "0")}</div><div className="stat-foot"><span className="mini-dot violet-dot" /> Records matching your search</div></article>
            <article className="stat-card"><div className="stat-top"><span>Departments</span><div className="stat-icon blue"><Building2 size={19} /></div></div><div className="stat-number">{loading ? "—" : stats.departments.toString().padStart(2, "0")}</div><div className="stat-foot">Across listed students</div></article>
            <article className="stat-card"><div className="stat-top"><span>Second-year students</span><div className="stat-icon green"><GraduationCap size={20} /></div></div><div className="stat-number">{loading ? "—" : stats.secondYear.toString().padStart(2, "0")}</div><div className="stat-foot">Based on year field</div></article>
          </section>

          <section className="directory-card">
            <div className="directory-heading"><div><h2>All students</h2><p>Student records stored in your database</p></div><button className="outline-btn" onClick={loadStudents}><RefreshCw size={15} /> Refresh</button></div>
            <div className="toolbar"><div className="search-box"><Search size={17} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name, PRN or email..." aria-label="Search students" />{search && <button onClick={() => setSearch("")} aria-label="Clear search"><X size={15} /></button>}</div><span className="result-count">{students.length} {students.length === 1 ? "record" : "records"}</span></div>
            <div className="table-wrap">
              <table><thead><tr><th>STUDENT</th><th>PRN / ID</th><th>DEPARTMENT</th><th>YEAR</th><th>CONTACT</th><th className="actions-heading">ACTIONS</th></tr></thead>
                <tbody>
                  {loading ? <tr><td colSpan="6"><div className="empty-state"><div className="spinner" /><strong>Loading student records...</strong></div></td></tr>
                  : students.length === 0 ? <tr><td colSpan="6"><div className="empty-state"><div className="empty-icon"><Users size={24} /></div><strong>{search ? "No matching students" : "No students added yet"}</strong><p>{search ? "Try a different name, PRN, or email." : "Add your first student to start building your directory."}</p>{!search && <button className="primary-btn" onClick={openAdd}><UserPlus size={16} /> Add first student</button>}</div></td></tr>
                  : students.map((student, index) => <tr key={student._id}><td><div className="student-cell"><div className={`student-avatar avatar-${index % 5}`}>{initials(student.name)}</div><div><strong>{student.name}</strong><small>{student.email}</small></div></div></td><td><span className="prn">{student.prn}</span></td><td><span className="department-pill">{student.department}</span></td><td><span className="year-pill">{student.year}</span></td><td><div className="contact-cell">{student.phone ? <><Phone size={13} /> {student.phone}</> : <><Mail size={13} /> {student.email}</>}</div></td><td><div className="row-actions"><button className="action-btn edit" onClick={() => openEdit(student)} aria-label={`Edit ${student.name}`} title="Edit student"><Pencil size={15} /></button><button className="action-btn delete" onClick={() => deleteStudent(student)} aria-label={`Delete ${student.name}`} title="Delete student"><Trash2 size={15} /></button></div></td></tr>)}
                </tbody>
              </table>
            </div>
            <div className="table-footer"><span>Live data from MongoDB</span><span><span className="live-dot" /> Connected through API when backend is running</span></div>
          </section>
          <footer className="footer"><span>© 2026 CampusFlow · FLEXI Project</span><span>Built with React · Node.js · MongoDB</span></footer>
        </div>
      </main>

      {modalOpen && <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) setModalOpen(false); }}>
        <section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
          <div className="modal-heading"><div><div className="eyebrow">{editingId ? "UPDATE RECORD" : "NEW RECORD"}</div><h2 id="modal-title">{editingId ? "Edit student" : "Add a student"}</h2><p>Enter the student's details below.</p></div><button className="icon-btn" onClick={() => setModalOpen(false)} aria-label="Close form"><X size={19} /></button></div>
          {error && <div className="form-error">{error}</div>}
          <form onSubmit={handleSubmit}>
            <label>Full name <span>*</span><div className="input-wrap"><Users size={16} /><input required minLength="2" maxLength="80" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Aditi Sharma" /></div></label>
            <div className="form-row"><label>PRN / Student ID <span>*</span><div className="input-wrap"><Hash size={16} /><input required maxLength="40" value={form.prn} onChange={(e) => setForm({ ...form, prn: e.target.value })} placeholder="e.g. 25070521280" /></div></label><label>Phone number<div className="input-wrap"><Phone size={16} /><input type="tel" maxLength="20" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="Optional" /></div></label></div>
            <label>Email address <span>*</span><div className="input-wrap"><Mail size={16} /><input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="student@example.com" /></div></label>
            <div className="form-row"><label>Department <span>*</span><div className="input-wrap"><Building2 size={16} /><select required value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })}><option>Computer Science</option><option>Information Technology</option><option>Electronics</option><option>Mechanical Engineering</option><option>Civil Engineering</option><option>Electrical Engineering</option><option>Artificial Intelligence</option><option>Other</option></select></div></label><label>Academic year <span>*</span><div className="input-wrap"><GraduationCap size={16} /><select required value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })}><option>1st Year</option><option>2nd Year</option><option>3rd Year</option><option>4th Year</option></select></div></label></div>
            <div className="modal-actions"><button type="button" className="outline-btn" onClick={() => setModalOpen(false)}>Cancel</button><button type="submit" className="primary-btn" disabled={saving}>{saving ? "Saving..." : editingId ? "Save changes" : <><UserPlus size={16} /> Add student</>}</button></div>
          </form>
        </section>
      </div>}
    </div>
  );
}
