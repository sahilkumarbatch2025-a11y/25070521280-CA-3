# Student Management System — FLEXI Project

Full-stack CRUD application using React + Vite, Node.js, Express, Mongoose, and MongoDB.

## Requirements
- Node.js and npm
- MongoDB Community Server running locally
- MongoDB Compass (optional, to inspect data)

## 1. Open the project
Extract the ZIP, then open the `Student-Management-System` folder in VS Code.

## 2. Install dependencies
Open a terminal in VS Code and run:

```bash
cd backend
npm install
```

Open a **second terminal** and run:

```bash
cd frontend
npm install
```

## 3. Configure MongoDB
The backend `.env` file uses:
`MONGO_URI=mongodb://127.0.0.1:27017/student_management`

Make sure MongoDB Server is running. MongoDB Compass is a GUI; Compass alone does not start the database server.

## 4. Start the backend
In the backend terminal:

```bash
npm run dev
```

Expected message: `Server running on http://localhost:5000` and a successful MongoDB connection message.

## 5. Start the frontend
In the frontend terminal:

```bash
npm run dev
```

Open the local URL Vite prints (usually http://localhost:5173).

## Features
- Dashboard summary
- Add, list, search, edit, and delete students
- MongoDB persistence
- Form validation and error messages
- Responsive layout

## Student fields
Name, PRN, email, department, year, phone.

## API endpoints
- `GET /api/students` — list/search students (`?search=`)
- `GET /api/students/:id` — get one student
- `POST /api/students` — add student
- `PUT /api/students/:id` — update student
- `DELETE /api/students/:id` — delete student

If your MongoDB service is not running, start the MongoDB Server service or install/start MongoDB Community Server first.
